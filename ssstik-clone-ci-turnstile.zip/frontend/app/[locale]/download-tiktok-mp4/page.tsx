"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import Turnstile from '@marsidev/react-turnstile';

export default function DownloadMp4Page({ params }: { params: { locale: string } }) {
  const t = useTranslations();
  const [url, setUrl] = useState('');
  const [queueMode, setQueueMode] = useState(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null);

  async function handleDownload() {
    const qs = new URLSearchParams();
    qs.append('url', url);
    if (queueMode) qs.append('queue_mode', 'true');
    if (turnstileToken) qs.append('cf-turnstile-response', turnstileToken);
    const base = process.env.NEXT_PUBLIC_API_BASE_URL;
    const res = await fetch(`${base}/api/download-mp4?${qs.toString()}`);
    if (queueMode) {
      const data = await res.json();
      setJobId(data.job_id);
    } else {
      const blob = await res.blob();
      const disposition = res.headers.get('Content-Disposition');
      const match = disposition?.match(/filename=\"?([^;]+)\"?/);
      const filename = match ? match[1] : 'video.mp4';
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(blobUrl);
    }
  }

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">{t('download.mp4.title')}</h1>
      <input
        type="text"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        placeholder={t('input.placeholder')}
        className="w-full p-2 border rounded mb-2"
      />
      <label className="flex items-center mb-2">
        <input
          type="checkbox"
          checked={queueMode}
          onChange={(e) => setQueueMode(e.target.checked)}
          className="mr-2"
        />
        {t('queue.label')}
      </label>
      {process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY && (
        <div className="mb-2">
          <Turnstile
            siteKey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY!}
            onSuccess={(token) => setTurnstileToken(token)}
          />
        </div>
      )}
      <button
        onClick={handleDownload}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        {t('download.button')}
      </button>
      {jobId && (
        <p className="mt-2">
          {t('job.id')}: {jobId}
        </p>
      )}
    </div>
  );
}