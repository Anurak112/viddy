import { ReactNode } from 'react';
import { NextIntlClientProvider, useMessages } from 'next-intl';
import '../globals.css';

export default function LocaleLayout({ children, params }: { children: ReactNode; params: { locale: string } }) {
  const messages = useMessages();
  return (
    <html lang={params.locale}>
      <body>
        <NextIntlClientProvider locale={params.locale} messages={messages}>
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  );
}