"use client";

import { useTranslations } from 'next-intl';
import Link from 'next/link';

export default function LocaleHome({ params }: { params: { locale: string } }) {
  const t = useTranslations();
  const { locale } = params;
  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-3xl font-bold mb-6">{t('home.title')}</h1>
      <nav className="space-y-4">
        <Link href={`/${locale}/download-tiktok-mp3`} className="block text-blue-600 underline">
          {t('nav.mp3')}
        </Link>
        <Link href={`/${locale}/download-tiktok-mp4`} className="block text-blue-600 underline">
          {t('nav.mp4')}
        </Link>
        <Link href={`/${locale}/download-stories`} className="block text-blue-600 underline">
          {t('nav.story')}
        </Link>
      </nav>
    </div>
  );
}