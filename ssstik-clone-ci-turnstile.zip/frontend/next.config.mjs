import nextIntl from 'next-intl/plugin';

// Configure next-intl to support English and Thai locales. The default locale
// is English and the locale prefix is applied only when necessary. See
// https://next-intl-docs.vercel.app for details.
const withNextIntl = nextIntl({
  locales: ['en', 'th'],
  defaultLocale: 'en',
  localePrefix: 'as-needed'
});

const nextConfig = {
  experimental: {
    appDir: true,
  },
};

export default withNextIntl(nextConfig);